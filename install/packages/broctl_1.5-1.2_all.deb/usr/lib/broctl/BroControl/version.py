#
# Settings that specify the version of BroControl
#

VERSION = "1.5"
BROBASE = "/usr"
CFGFILE = "/etc/bro/broctl.cfg"
BROSCRIPTDIR = "/usr/share/bro"
